rm *.pdf
pdflatex -interaction nonstopmode -shell-escape -synctex=1 Sample.tex
bibtex main
pdflatex -interaction nonstopmode -shell-escape -synctex=1 Sample.tex
pdflatex -interaction nonstopmode -shell-escape -synctex=1 Sample.tex
xreader main.pdf

